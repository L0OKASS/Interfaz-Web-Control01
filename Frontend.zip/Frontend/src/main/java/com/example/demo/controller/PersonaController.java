package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.PersonaEntity;
import com.example.demo.interfaces.PersonaService;

@Controller
@RequestMapping("crud/persona")
public class PersonaController {

    @Autowired
    private PersonaService service;

    // LISTAR
    @GetMapping("/")
    public String listar(Model model) {
        List<PersonaEntity> personas = service.listarTodos();
        model.addAttribute("personas", personas);
        model.addAttribute("persona", new PersonaEntity());
        return "index";
    }

    // GUARDAR
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute PersonaEntity persona) {
        service.save(persona);
        return "redirect:/crud/persona/";
    }

    // ELIMINAR
    @GetMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/crud/persona/";
    }

    // EDITAR
    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        PersonaEntity persona = service.findById(id);
        model.addAttribute("persona", persona);
        return "index";
    }
}