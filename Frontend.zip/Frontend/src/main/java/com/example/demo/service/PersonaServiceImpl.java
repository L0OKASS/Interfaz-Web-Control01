package com.example.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.PersonaEntity;
import com.example.demo.interfaces.PersonaService;

@Service
public class PersonaServiceImpl implements PersonaService {

    private final String URL = "http://localhost:8080/api/v1/entities/persona/";

    @Override
    public List<PersonaEntity> listarTodos() {
        RestTemplate restTemplate = new RestTemplate();
        PersonaEntity[] response = restTemplate.getForObject(URL, PersonaEntity[].class);

        if (response == null) return List.of();

        return Arrays.asList(response);
    }

    @Override
    public PersonaEntity findById(Long id) {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(URL + id, PersonaEntity.class);
    }

    @Override
    public PersonaEntity save(PersonaEntity persona) {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.postForObject(URL, persona, PersonaEntity.class);
    }

    @Override
    public void deleteById(Long id) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(URL + id);
    }

}