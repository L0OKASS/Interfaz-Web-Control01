package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.PersonaEntity;
import com.example.demo.service.PersonaServiceImpl;

@RestController
@RequestMapping("/api/personas")
public class PersonaController {

    @Autowired
    private PersonaServiceImpl service;

    @GetMapping
    public List<PersonaEntity> listar() {
        return service.listarTodos();
    }

    @PostMapping
    public PersonaEntity guardar(@RequestBody PersonaEntity persona) {
        return service.save(persona);
    }
}