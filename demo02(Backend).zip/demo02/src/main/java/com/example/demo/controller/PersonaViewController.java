package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.PersonaEntity;
import com.example.demo.service.PersonaServiceImpl;

@Controller
public class PersonaViewController {

    @Autowired
    private PersonaServiceImpl service;

    // 🔹 LISTAR
    @GetMapping("/crud/persona/")
    public String listar(Model model) {
        model.addAttribute("personas", service.listarTodos());
        model.addAttribute("persona", new PersonaEntity());
        return "index";
    }

    // 🔹 GUARDAR (crear o editar)
    @PostMapping("/crud/persona/guardar")
    public String guardar(@ModelAttribute PersonaEntity persona) {
        service.save(persona);
        return "redirect:/crud/persona/";
    }

    // 🔹 EDITAR (cargar datos)
    @GetMapping("/crud/persona/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        PersonaEntity persona = service.findById(id);
        model.addAttribute("personas", service.listarTodos());
        model.addAttribute("persona", persona);
        return "index";
    }

    // 🔹 ELIMINAR
    @GetMapping("/crud/persona/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/crud/persona/";
    }
}
