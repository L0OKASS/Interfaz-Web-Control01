package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.PersonaEntity;
import com.example.demo.interfaces.PersonaService;
import com.example.demo.repository.PersonaRepository;

@Service
public class PersonaServiceImpl implements PersonaService {

    @Autowired
    private PersonaRepository repository;

    @Override
    public List<PersonaEntity> listarTodos() {
        return repository.findAll();
    }

    @Override
    public PersonaEntity findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public PersonaEntity save(PersonaEntity persona) {
        return repository.save(persona);
    }

    @Override
    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}